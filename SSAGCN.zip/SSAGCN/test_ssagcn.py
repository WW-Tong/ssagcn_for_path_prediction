from __future__ import division
import os
import math
import sys
import torch
import numpy as np
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import pickle
import argparse
import glob
import torch.distributions.multivariate_normal as torchdist
from utils import * 
from metrics import * 
from model import SocialSoftAttentionGCN
import copy
import seaborn as sns
import matplotlib.pyplot as plt
import time
import networkx as nx

def test(KSTEPS=20,scale=0.05):
    global loader_test,model
    model.eval()
    ade_bigls = []
    fde_bigls = []
    raw_data_dict = {}
    step =0 
    for batch in loader_test: 
        step+=1
        #Get data
        batch = [tensor.cuda() for tensor in batch]
        obs_traj, pred_traj_gt, obs_traj_rel, pred_traj_gt_rel, non_linear_ped,\
         loss_mask,V_obs,A_obs,V_tr,A_tr,vgg_list = batch
        obs_traj*=scale
        pred_traj_gt*=scale
        obs_traj_rel*=scale
        pred_traj_gt_rel*=scale
        V_obs*=scale
        V_tr*=scale
        num_of_objs = obs_traj_rel.shape[1]
        V_obs_tmp =V_obs.permute(0,3,1,2)
        V_pred,_ = model(V_obs_tmp,A_obs.squeeze(),vgg_list)
        V_pred = V_pred.permute(0,2,3,1)


        V_tr = V_tr.squeeze()
        A_tr = A_tr.squeeze()
        V_pred = V_pred.squeeze()
        num_of_objs = obs_traj_rel.shape[1]
        V_pred,V_tr =  V_pred[:,:num_of_objs,:],V_tr[:,:num_of_objs,:]
        sx = torch.exp(V_pred[:,:,2]) #sx
        sy = torch.exp(V_pred[:,:,3]) #sy
        corr = torch.tanh(V_pred[:,:,4]) #corr
        
        cov = torch.zeros(V_pred.shape[0],V_pred.shape[1],2,2).cuda()
        cov[:,:,0,0]= sx*sx
        cov[:,:,0,1]= corr*sx*sy
        cov[:,:,1,0]= corr*sx*sy
        cov[:,:,1,1]= sy*sy
        mean = V_pred[:,:,0:2]
        
        mvnormal = torchdist.MultivariateNormal(mean,cov)


        ### Rel to abs 
        ##obs_traj.shape = torch.Size([1, 6, 2, 8]) Batch, Ped ID, x|y, Seq Len 
        
        #Now sample 20 samples
        ade_ls = {}
        fde_ls = {}
        V_x = seq_to_nodes(obs_traj.data.cpu().numpy().copy())
        V_x_rel_to_abs = nodes_rel_to_nodes_abs(V_obs.data.cpu().numpy().squeeze().copy(),
                                                 V_x[0,:,:].copy())

        V_y = seq_to_nodes(pred_traj_gt.data.cpu().numpy().copy())
        V_y_rel_to_abs = nodes_rel_to_nodes_abs(V_tr.data.cpu().numpy().squeeze().copy(),
                                                 V_x[-1,:,:].copy())
        
        raw_data_dict[step] = {}
        raw_data_dict[step]['obs'] = copy.deepcopy(V_x_rel_to_abs)
        raw_data_dict[step]['trgt'] = copy.deepcopy(V_y_rel_to_abs)
        raw_data_dict[step]['pred'] = []

        for n in range(num_of_objs):
            ade_ls[n]=[]
            fde_ls[n]=[]

        for k in range(KSTEPS):

            V_pred = mvnormal.sample()
            V_pred_rel_to_abs = nodes_rel_to_nodes_abs(V_pred.data.cpu().numpy().squeeze().copy(),
                                                     V_x[-1,:,:].copy())

            # draw graph
            # edge_colors=[]
            # Vtr=pred_traj_gt.squeeze(dim=0).permute(2,0,1).data.cpu().numpy()[0]
            # adj=A_obs.squeeze(dim=0).data.cpu().numpy()[-1]
            # for i in adj.flatten() :
            #     if i>0:
            #         # i=np.ceil(i)*30
            #         edge_colors.append(i)            
            # adj_one=adj/adj
            # adj_one[np.isnan(adj_one)]=0
            # G = nx.from_numpy_matrix(adj_one)
            # pos=Vtr
            # for u,v,d in G.edges(data=True):
            #     d['weight'] = adj[u][v]
            # plt.title("Batch:"+str(step))
            # edges,weights = zip(*nx.get_edge_attributes(G,'weight').items())
            # # nodes = nx.draw_networkx_nodes(G, pos, node_size=100, node_color='red')
            # edgess = nx.draw_networkx_edges(G, pos, node_size=100,
            #                    arrowsize=10, edge_color=weights,
            #                    edge_cmap=plt.cm.BuGn, width=2)
            # nx.draw(G, pos, node_color='b', edgelist=edges, edge_color=weights, width=10.0, edge_cmap=plt.cm.BuPu)
            # ax = plt.gca()
            # ax.set_axis_off()
            # plt.colorbar(edgess)
            # for i in range(obs_traj.shape[1]) :
            #     obs_traj=torch.cat((obs_traj,pred_traj_gt[:,:,:,0].unsqueeze(dim=3)),3)   # NVCT
            #     plt.plot(obs_traj[0,i,0,:].cpu().numpy(), obs_traj[0,i,1,:].cpu().numpy(), 'm.-.',color='blue', label='training accuracy')
            #     plt.plot(pred_traj_gt[0,i,0,:].cpu().numpy(), pred_traj_gt[0,i,1,:].cpu().numpy(), 'm.-.',color='red', label='training accuracy')
            
            # plt.show()

            colors=list(['Blues','Greens','Oranges','Reds','PuRd','PuBu','Purples'])

            if step==241:
                for i in range(obs_traj.shape[1]) :

                    ax = sns.kdeplot(V_pred_rel_to_abs[:,i,0],V_pred_rel_to_abs[:,i,1],shade = True, cmap = colors[i%6])
                    ax.patch.set_facecolor('white')
                    ax.collections[0].set_alpha(0)
                    obs_traj=torch.cat((obs_traj,pred_traj_gt[:,:,:,0].unsqueeze(dim=3)),3)   # NVCT
                    plt.plot(obs_traj[0,i,0,:].cpu().numpy(), obs_traj[0,i,1,:].cpu().numpy(), 'm.-.',color='blue', label='training accuracy')
                    plt.plot(pred_traj_gt[0,i,0,:].cpu().numpy(), pred_traj_gt[0,i,1,:].cpu().numpy(), 'm.-.',color='red', label='training accuracy')
                plt.title("Batch:"+str(step))
                
                    
                plt.show()

            
            raw_data_dict[step]['pred'].append(copy.deepcopy(V_pred_rel_to_abs))
     
            for n in range(num_of_objs):
                pred = [] 
                target = []
                obsrvs = [] 
                number_of = []
                pred.append(V_pred_rel_to_abs[:,n:n+1,:])
                target.append(V_y_rel_to_abs[:,n:n+1,:])
                obsrvs.append(V_x_rel_to_abs[:,n:n+1,:])
                number_of.append(1)

                ade_ls[n].append(ade(pred,target,number_of))
                fde_ls[n].append(fde(pred,target,number_of))
        
        for n in range(num_of_objs):
            ade_bigls.append(min(ade_ls[n]))
            fde_bigls.append(min(fde_ls[n]))

    ade_ = sum(ade_bigls)/len(ade_bigls)
    fde_ = sum(fde_bigls)/len(fde_bigls)
    return ade_,fde_,raw_data_dict

if __name__ == '__main__':
    paths = ['./checkpoint/*ssagcn*']
    KSTEPS=20
    print("*"*50)
    print('Number of samples:',KSTEPS)
    print("*"*50)
   



    for feta in range(len(paths)):
        ade_ls = [] 
        fde_ls = [] 
        path = paths[feta]
        exps = glob.glob(path)
        print('Model being tested are:',exps)

        for exp_path in exps:
            print("*"*50)
            print("Evaluating model:",exp_path)

            model_path = exp_path+'/val_best.pth'
            args_path = exp_path+'/args.pkl'
            with open(args_path,'rb') as f: 
                args = pickle.load(f)
            scale=args.scale
            stats= exp_path+'/constant_metrics.pkl'
            with open(stats,'rb') as f: 
                cm = pickle.load(f)
            print("Stats:",cm)



            #Data prep     
            obs_seq_len = args.obs_seq_len
            pred_seq_len = args.pred_seq_len
      
            dset_test = torch.load("./data/"+args.dataset+"_test.pt")

            print("data %s load compelte"%args.dataset)
            # dset_test = TrajectoryDataset(
            #         data_set+'test/',
            #         obs_len=obs_seq_len,
            #         pred_len=pred_seq_len,
            #         skip=1,norm_lap_matr=True)

            loader_test = DataLoader(
                    dset_test,
                    batch_size=1,
                    shuffle =False,
                    num_workers=1)



            #Defining the model 
            model = SocialSoftAttentionGCN(stgcn_num =args.n_ssagcn,tcn_num=args.n_txpcnn,
            output_feat=args.output_size,seq_len=args.obs_seq_len,
            kernel_size=args.kernel_size,pred_seq_len=args.pred_seq_len).cuda()
            model.load_state_dict(torch.load(model_path))

            ade_ =999999
            fde_ =999999
            print("Testing ....")
            time_start = time.time()
            ad,fd,raw_data_dic_= test(KSTEPS,scale)
            time_end = time.time()
            ade_= min(ade_,ad)/scale
            fde_ =min(fde_,fd)/scale
            ade_ls.append(ade_)
            fde_ls.append(fde_)
            print("ADE:",ade_/scale," FDE:",fde_/scale)




        print("*"*50)

        print("Avg ADE:",sum(ade_ls)/len(ade_ls)/scale)
        print("Avg FDE:",sum(fde_ls)/len(ade_ls)/scale)